<script src="<?= base_url('js/jquery.min.js'); ?>"></script>
<script src="<?= base_url('js/bootstrap.bundle.min.js'); ?>"></script>
<script src="<?= base_url('js/jquery.easing.min.js'); ?>"></script>
<script src="<?= base_url('js/sb-admin-2.min.js'); ?>"></script>
<script src="<?= base_url('js/sweetalert2.all.min.js'); ?>"></script>
<script src="<?= base_url('js/swiper-bundle.min.js'); ?>"></script>
<!-- <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script> -->
<script src="https://cdn.tiny.cloud/1/gpe91r6ssffac21qy6khpp92qa4cxrxkjmhawlmdb63l65ho/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<script src="<?= base_url('js/suggestions.js'); ?>"></script>
<script src="<?= base_url('js/script.js'); ?>"></script>
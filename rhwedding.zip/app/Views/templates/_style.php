<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
<link rel="stylesheet" href="<?= base_url('css/sb-admin-2.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('css/swiper-bundle.min.css'); ?>">
<!-- <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"> -->
<link rel="stylesheet" href="<?= base_url('css/style.css'); ?>">